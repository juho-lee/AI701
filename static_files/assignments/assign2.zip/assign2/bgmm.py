import numpy as np
import numpy.random as npr
from scipy.special import logsumexp
from scipy.stats import dirichlet
from scipy.stats import norm
from scipy.stats import multivariate_normal as mvn

class BGMMSampler(object):
    def __init__(self, X, K,
            alpha = 1.0,
            sigma_mu = np.sqrt(5.0),
            sigma_lamb = np.sqrt(0.1),
            sigma_v = np.sqrt(0.25)):

        self.X = X
        self.N, self.d = X.shape
        self.K = K

        self.alpha = alpha
        self.p_beta = dirichlet(alpha*np.ones(K))
        self.beta = self.p_beta.rvs().squeeze()

        self.p_mu = mvn(np.zeros(self.d), sigma_mu**2 * np.eye(self.d))
        self.p_loglamb = norm(0.1, sigma_lamb**2)
        self.p_v = mvn(np.zeros(self.d), sigma_v**2 * np.eye(self.d))

        self.mus = np.stack([self.p_mu.rvs() for k in range(K)])
        self.loglambs = np.stack([self.p_loglamb.rvs() for k in range(K)])
        self.vs = np.stack([self.p_v.rvs() for k in range(K)])
        self.beta = npr.dirichlet(alpha*np.ones(K))

        self.z = np.zeros(len(X), dtype=int)

    def log_joint(self):
        y = self.p_beta.logpdf(self.beta)
        for k in range(self.K):
            Sigma = np.exp(self.loglambs[k])*np.eye(self.d) \
                    + np.outer(self.vs[k], self.vs[k])
            Xk = self.X[self.z==k]
            y += len(Xk) * np.log(self.beta[k])
            y += mvn(self.mus[k], Sigma).logpdf(Xk).sum()
            y += self.p_mu.logpdf(self.mus[k])
            y += self.p_loglamb.logpdf(self.loglambs[k]) - self.loglambs[k]
            y += self.p_v.logpdf(self.vs[k])
        return y

    def sample_params(self, sigma_q=0.05):
        # sample beta
        Nk = np.bincount(self.z, minlength=self.K)
        self.beta = dirichlet(self.alpha + Nk).rvs().squeeze()

        # sample mu, lamb, v
        for k in range(self.K):
            Xk = self.X[self.z==k]

            mu = self.mus[k]
            loglamb = self.loglambs[k]
            v = self.vs[k]
            Sigma = np.exp(loglamb)*np.eye(self.d) + np.outer(v, v)

            mu_new = mu + sigma_q*npr.normal(size=self.d)
            loglamb_new = loglamb + sigma_q*npr.normal()
            v_new = v + sigma_q*npr.normal(size=self.d)
            Sigma_new = np.exp(loglamb_new)*np.eye(self.d) + np.outer(v_new, v_new)

            log_rho = mvn(mu_new, Sigma_new).logpdf(Xk).sum() \
                    + self.p_mu.logpdf(mu_new) \
                    + self.p_loglamb.logpdf(loglamb_new) \
                    + self.p_v.logpdf(v_new) \
                    - mvn(mu, Sigma).logpdf(Xk).sum() \
                    - self.p_mu.logpdf(mu) \
                    - self.p_loglamb.logpdf(loglamb) \
                    - self.p_v.logpdf(v)

            if npr.rand() < np.exp(min(log_rho, 0.0)):
                self.mus[k] = mu_new
                self.loglambs[k] = loglamb_new
                self.vs[k] = v_new

    def sample_z(self):

        log_probs = np.zeros((self.N, self.K))
        log_probs += np.log(self.beta)[None]
        for k in range(self.K):
            Sigma = np.exp(self.loglambs[k])*np.eye(self.d) \
                    + np.outer(self.vs[k], self.vs[k])
            log_probs[:,k] += mvn(self.mus[k], Sigma).logpdf(self.X)
        probs = np.exp(log_probs - logsumexp(log_probs, axis=-1, keepdims=True))
        cprobs = probs.cumsum(-1)
        self.z = (npr.rand(self.N, 1) < cprobs).argmax(-1)

    def run(self, num_steps, burn_in=None, thin=10):

        burn_in = burn_in or (num_steps // 2)
        states = []

        for step in range(1, num_steps+1):
            self.sample_z()
            self.sample_params()

            if step % 100 == 0:
                print(f"step {step} log-joint {self.log_joint():.4f}")

            if step > burn_in and step % thin == 0:
                state = {
                        'step':step,
                        'lj':self.log_joint(),
                        "mus":self.mus,
                        "loglambs":self.loglambs,
                        "vs":self.vs,
                        }
                states.append(state)

        return states

if __name__ == "__main__":

    from plots import scatter_mog
    import matplotlib.pyplot as plt

    X = np.loadtxt("X.txt")

    sampler = BGMMSampler(X, 3)
    states = sampler.run(10000)

    mus = np.stack([state["mus"] for state in states]).mean(0)
    Sigmas = np.stack([np.exp(state["loglambs"])[:,None,None]*np.eye(2)[None] + \
            state["vs"][:,:,None] @ state["vs"][:,None,:] for state in states]).mean(0)

    fig, axes = plt.subplots(1, 2, figsize=(12, 6))
    axes[0].plot([state["step"] for state in states], [state["lj"] for state in states])
    scatter_mog(X, sampler.z, mus, Sigmas, ax=axes[1])
    plt.tight_layout()
    plt.show()
